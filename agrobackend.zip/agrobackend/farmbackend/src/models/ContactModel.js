const mongoose = require('mongoose');
const ContactSchema = new mongoose.Schema(
    {
      name: {
        type: String
      },
      phone: {
        type: String
      },
      Email: {
        type: String
      },
      Subject: {
        type: String
      },
      Message: {
        type: String
      },
    },
    { timestamps: true }
  );
  
  module.exports = mongoose.model("contact", ContactSchema);